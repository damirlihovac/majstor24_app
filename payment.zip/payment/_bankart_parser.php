<?php
declare(strict_types=1);

function bankart_parse(array $data): array
{
    return [

        /* ================= BASIC ================= */

        'status' => strtoupper(trim(
            $data['result']
            ?? $data['status']
            ?? ''
        )),

        'trx' => trim(
            $data['merchantTransactionId']
            ?? $data['merchant_trx_id']
            ?? $data['trx']
            ?? ''
        ),

        'uuid' => trim(
            $data['uuid']
            ?? $data['purchaseId']
            ?? ''
        ),

        /* ================= COF ================= */

        'registrationId' => 
            $data['extraData']['adapterRegistrationId']
            ?? $data['returnData']['adapterRegistrationId']
            ?? '',

        /* ================= CARD ================= */

        'cardHolder' => $data['returnData']['cardHolder'] ?? '',

        'brand' => $data['paymentMethod']
            ?? $data['returnData']['type']
            ?? 'CARD',

        'firstSix' => $data['returnData']['firstSixDigits'] ?? '',
        'lastFour' => $data['returnData']['lastFourDigits'] ?? '',

        'masked' => (
            !empty($data['returnData']['firstSixDigits']) &&
            !empty($data['returnData']['lastFourDigits'])
        )
            ? $data['returnData']['firstSixDigits'].'****'.$data['returnData']['lastFourDigits']
            : '****',

        /* ================= CUSTOMER ================= */

        'email' =>
            $data['customer']['email']
            ?? $data['customerEmail']
            ?? '',

        'contactId' => (int)(
            $data['customer']['identification']
            ?? 0
        ),

        /* ================= RAW ================= */

        'raw' => $data
    ];
}

/* ================= SUCCESS CHECK ================= */

function bankart_is_success(string $status): bool
{
    return in_array($status, [
        'OK','SUCCESS','APPROVED','PAID',
        'CAPTURED','COMPLETED','AUTHORIZED','AUTHORISED','REGISTERED'
    ], true);
}
