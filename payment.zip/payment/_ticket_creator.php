<?php
declare(strict_types=1);

function create_ticket_from_pending(PDO $pdo,int $contactId,string $trx):array
{

/* =====================================================
   LOAD PENDING
===================================================== */

$stmt=$pdo->prepare("
SELECT id,payload_json,ticket_id
FROM m24_pending_ticket
WHERE merchant_trx_id=?
ORDER BY id DESC
LIMIT 1
");

$stmt->execute([$trx]);
$row=$stmt->fetch(PDO::FETCH_ASSOC);

if(!$row){
    throw new Exception("PENDING_NOT_FOUND");
}

/* =====================================================
   IDEMPOTENCY
===================================================== */

if(!empty($row['ticket_id'])){
    return [
        "ticket_ws_id"=>$row['ticket_id'],
        "status"=>"ALREADY_CREATED"
    ];
}

/* =====================================================
   PAYLOAD
===================================================== */

$payload=json_decode($row['payload_json'],true);

$request=$payload['request'] ?? [];
$termin =$payload['termin']  ?? [];

/* =====================================================
   DATA
===================================================== */

$adresa   = $request['adresa']   ?? '';
$ptt      = $request['ptt']      ?? '';
$mjesto   = $request['mjesto']   ?? '';
$usluga   = $request['usluga']   ?? '';
$podgrupa = $request['podgrupa'] ?? '';
$cijena   = $request['cijena']   ?? '0';
$napomene = $request['napomene'] ?? '';

$datum    = $termin['datum']     ?? '';
$vrijeme  = $termin['vrijeme']   ?? '';

$opis = $napomene ?: 'Online zahtjev iz mobilne aplikacije.';

$title = trim("Zahtjev {$usluga} {$podgrupa} {$cijena}");

/* =====================================================
   ENV
===================================================== */

$env=parse_ini_file('/var/www/majstor24_env/core-api.env');

$CRM_URL       = $env['VTIGER_URL'];
$CRM_USERNAME  = $env['VTIGER_USERNAME'];
$CRM_ACCESSKEY = $env['VTIGER_ACCESS_KEY'];

$wsContactId="12x".$contactId;

/* =====================================================
   GET CHALLENGE
===================================================== */

$challenge=json_decode(
file_get_contents(
$CRM_URL."?operation=getchallenge&username=".urlencode($CRM_USERNAME)
),
true
);

if(empty($challenge['success'])){
    throw new Exception("CRM_CHALLENGE_FAILED");
}

$token=$challenge['result']['token'];
$accessKey=md5($token.$CRM_ACCESSKEY);

/* =====================================================
   LOGIN
===================================================== */

$ch=curl_init($CRM_URL);

curl_setopt_array($ch,[
CURLOPT_RETURNTRANSFER=>true,
CURLOPT_POST=>true,
CURLOPT_POSTFIELDS=>http_build_query([
'operation'=>'login',
'username'=>$CRM_USERNAME,
'accessKey'=>$accessKey
])
]);

$login=json_decode(curl_exec($ch),true);
curl_close($ch);

if(empty($login['success'])){
    throw new Exception("CRM_LOGIN_FAILED");
}

$sessionName=$login['result']['sessionName'];

/* =====================================================
   CRM FIELD MAPPING
===================================================== */

$ticket=[

"ticket_title"=>$title,
"description"=>$opis,
"ticketstatus"=>"Open",
"ticketpriorities"=>"Normal",

"assigned_user_id"=>"19x1",
"contact_id"=>$wsContactId,

"cf_888"=>$usluga,
"cf_920"=>$podgrupa,
"cf_922"=>$adresa,
"cf_924"=>$ptt,
"cf_892"=>$napomene,
"cf_894"=>$datum,
"cf_896"=>$vrijeme,
"cf_898"=>"0",
"cf_902"=>"kartica",
"cf_904"=>$cijena,
"cf_906"=>"",
"cf_910"=>$mjesto,
"cf_914"=>$opis
];

/* =====================================================
   CREATE TICKET
===================================================== */

$post=http_build_query([
'operation'=>'create',
'sessionName'=>$sessionName,
'elementType'=>'HelpDesk',
'element'=>json_encode($ticket,JSON_UNESCAPED_UNICODE)
]);

$ch=curl_init($CRM_URL);

curl_setopt_array($ch,[
CURLOPT_RETURNTRANSFER=>true,
CURLOPT_POST=>true,
CURLOPT_POSTFIELDS=>$post,
CURLOPT_SSL_VERIFYHOST=>0,
CURLOPT_SSL_VERIFYPEER=>false
]);

$response=curl_exec($ch);
curl_close($ch);

$crmResp=json_decode($response,true);

if(empty($crmResp['success'])){
    error_log("[ticket_creator_mobile] ".json_encode($crmResp));
    throw new Exception("TICKET_CREATE_FAILED");
}

$ticketWsId=$crmResp['result']['id'];

/* =====================================================
   UPDATE TABLE
===================================================== */

$stmt=$pdo->prepare("
UPDATE m24_pending_ticket
SET ticket_id=?,status='CREATED',updated_at=NOW()
WHERE id=?
");

$stmt->execute([
$ticketWsId,
$row['id']
]);

return [
"ticket_ws_id"=>$ticketWsId,
"status"=>"CREATED"
];

}
