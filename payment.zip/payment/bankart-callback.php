<?php
declare(strict_types=1);

ini_set('display_errors','0');
ini_set('log_errors','1');
ini_set('error_log', __DIR__ . '/bankart_callback_error.log');
error_reporting(E_ALL);

header("Content-Type: application/json; charset=utf-8");

function respond(int $code, array $data){
    http_response_code($code);
    echo json_encode($data);
    exit;
}

$vtigerConfig = '/var/www/html/crmmajstor24/config.inc.php';

if(!file_exists($vtigerConfig)){
    respond(500,["success"=>false,"message"=>"CRM_CONFIG_NOT_FOUND"]);
}

require_once $vtigerConfig;

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try{

$db = new mysqli(
    $dbconfig['db_server'],
    $dbconfig['db_username'],
    $dbconfig['db_password'],
    $dbconfig['db_name']
);

$db->set_charset("utf8mb4");

}catch(Throwable $e){

respond(500,["success"=>false,"message"=>"DB_CONNECT_ERROR"]);

}

$raw = file_get_contents("php://input");

if(!$raw){
    respond(400,["success"=>false,"message"=>"EMPTY_CALLBACK"]);
}

$data = json_decode($raw,true);

if(!is_array($data)){
    respond(400,["success"=>false,"message"=>"INVALID_CALLBACK_JSON"]);
}

$trx =
$data['merchantTransactionId'] ??
$data['transactionId'] ??
$data['trx'] ??
null;

$status =
$data['status'] ??
$data['result'] ??
null;

if(!$trx){
    respond(400,["success"=>false,"message"=>"MISSING_TRX"]);
}

if(!$status){
    respond(400,["success"=>false,"message"=>"MISSING_STATUS"]);
}

if($status === "SUCCESS" || $status === "APPROVED"){

    $stmt = $db->prepare("
    UPDATE m24_pending_ticket
    SET status='PAID', updated_at=NOW()
    WHERE merchant_trx_id=?
    LIMIT 1
    ");

    $stmt->bind_param("s",$trx);
    $stmt->execute();
    $stmt->close();

    respond(200,["success"=>true,"status"=>"PAID"]);

}else{

    $stmt = $db->prepare("
    UPDATE m24_pending_ticket
    SET status='FAILED', updated_at=NOW()
    WHERE merchant_trx_id=?
    LIMIT 1
    ");

    $stmt->bind_param("s",$trx);
    $stmt->execute();
    $stmt->close();

    respond(200,["success"=>true,"status"=>"FAILED"]);

}
