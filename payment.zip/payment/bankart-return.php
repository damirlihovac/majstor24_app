<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| BANKART RETURN
|--------------------------------------------------------------------------
| Ovdje se korisnik vraća nakon plaćanja
| Backend pokreće verify proces i vraća korisnika u Flutter
*/

ini_set('display_errors','0');
ini_set('log_errors','1');
ini_set('error_log', __DIR__ . '/bankart_return_error.log');
error_reporting(E_ALL);

/*
|--------------------------------------------------------------------------
| LOG
|--------------------------------------------------------------------------
*/

function log_line(string $msg, array $data=[]): void
{
    $file = __DIR__.'/bankart_return.log';

    $line = "[".date("Y-m-d H:i:s")."] ".$msg;

    if($data){
        $line .= " ".json_encode($data,JSON_UNESCAPED_UNICODE);
    }

    file_put_contents($file,$line.PHP_EOL,FILE_APPEND);
}

/*
|--------------------------------------------------------------------------
| GET TRANSACTION ID
|--------------------------------------------------------------------------
*/

$trx =
$_GET['trx'] ??
$_GET['merchantTransactionId'] ??
$_GET['transactionId'] ??
'';

$trx = trim((string)$trx);

if($trx === ''){

    log_line("RETURN WITHOUT TRX",$_GET);

    $trx = "UNKNOWN";

}else{

    log_line("RETURN TRX",["trx"=>$trx]);

}

/*
|--------------------------------------------------------------------------
| ASYNC VERIFY
|--------------------------------------------------------------------------
*/

if($trx !== "UNKNOWN"){

    try{

        $verifyUrl =
        "https://majstor24.ba/api/payment/verify_ticket_payment.php?trx="
        . urlencode($trx);

        log_line("VERIFY URL",["url"=>$verifyUrl]);

        $ch = curl_init();

        curl_setopt_array($ch,[

            CURLOPT_URL => $verifyUrl,

            CURLOPT_RETURNTRANSFER => true,

            CURLOPT_TIMEOUT => 5,

            CURLOPT_CONNECTTIMEOUT => 3,

            CURLOPT_SSL_VERIFYPEER => true,

            CURLOPT_SSL_VERIFYHOST => 2

        ]);

        $response = curl_exec($ch);

        $error = curl_error($ch);

        curl_close($ch);

        log_line("VERIFY TRIGGERED",[
            "trx"=>$trx,
            "error"=>$error
        ]);

    }catch(Throwable $e){

        log_line("VERIFY EXCEPTION",[
            "trx"=>$trx,
            "error"=>$e->getMessage()
        ]);

    }

}

?>
<!DOCTYPE html>
<html lang="bs">
<head>

<meta charset="utf-8">

<meta http-equiv="Cache-Control" content="no-store"/>
<meta http-equiv="Pragma" content="no-cache"/>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Plaćanje obrađeno</title>

<style>

body{
font-family:Arial, Helvetica, sans-serif;
background:#f4f6f8;
margin:0;
display:flex;
align-items:center;
justify-content:center;
height:100vh;
}

.box{
background:white;
padding:40px;
border-radius:12px;
box-shadow:0 5px 20px rgba(0,0,0,0.1);
text-align:center;
width:90%;
max-width:400px;
}

.spinner{
margin:25px auto 0;
width:40px;
height:40px;
border:4px solid #ddd;
border-top:4px solid #2a7de1;
border-radius:50%;
animation:spin 1s linear infinite;
}

@keyframes spin{
0%{transform:rotate(0deg);}
100%{transform:rotate(360deg);}
}

</style>

<script>

/*
|--------------------------------------------------------------------------
| FLUTTER DEEP LINK
|--------------------------------------------------------------------------
*/

const trx = "<?php echo htmlspecialchars($trx,ENT_QUOTES); ?>";

function redirectToApp(){

    const deepLink = "majstor24://payment-result?trx="+trx;

    window.location.href = deepLink;

}

/*
|--------------------------------------------------------------------------
| WAIT FOR BACKEND VERIFY
|--------------------------------------------------------------------------
*/

setTimeout(redirectToApp,2500);

</script>

</head>

<body>

<div class="box">

<h2>Plaćanje obrađeno</h2>

<p>Molimo sačekajte...</p>

<div class="spinner"></div>

</div>

</body>
</html>
