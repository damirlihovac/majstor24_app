<?php
declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

/* ================= INPUT ================= */

$raw  = file_get_contents('php://input') ?: '';
$json = json_decode($raw, true);

$input = array_merge(
    is_array($json) ? $json : [],
    $_POST ?? [],
    $_GET ?? []
);

/* ================= PARSER ================= */

require_once __DIR__ . '/_bankart_parser.php';

$parsed = bankart_parse($input);

$trx    = $parsed['trx'];
$status = $parsed['status'];
$uuid   = $parsed['uuid'];

/* ================= HELPERS ================= */

function out(string $msg, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: text/plain; charset=utf-8');
    echo $msg;
    exit;
}

function log_cb(string $msg): void {
    file_put_contents(
        '/var/log/majstor24/callback_package.log',
        date('c') . ' | ' . $msg . "\n",
        FILE_APPEND
    );
}
function vtiger_post(string $url, array $postFields): array {
    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query($postFields),
        CURLOPT_TIMEOUT        => 30,
    ]);

    $raw = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($raw === false || $raw === '' || $err) {
        throw new Exception('VTIGER_HTTP_ERROR: ' . $err);
    }

    $json = json_decode($raw, true);

    if (!is_array($json)) {
        throw new Exception('VTIGER_INVALID_JSON: ' . $raw);
    }

    return $json;
}

/* ================= MAIN ================= */

try {

    /* ================= ENV ================= */

    $env = @parse_ini_file('/var/www/majstor24_env/core-api.env') ?: [];
    if (!$env) {
        log_cb('ENV_NOT_LOADED');
        out('ENV_NOT_LOADED', 500);
    }

    /* ================= DB ================= */

    $pdo = new PDO(
        "mysql:host={$env['M24_DB_HOST']};dbname={$env['M24_DB_NAME']};charset=utf8mb4",
        $env['M24_DB_USER'],
        $env['M24_DB_PASS'],
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );

    /* ================= INPUT ================= */

    $raw  = file_get_contents('php://input') ?: '';
    $json = json_decode($raw, true);

    $input = array_merge(
        is_array($json) ? $json : [],
        $_POST ?? [],
        $_GET ?? []
    );

    log_cb("RAW: " . $raw);

    /* ================= EXTRACT ================= */

    $trx = trim((string)(
        $input['merchantTransactionId']
        ?? $input['merchant_trx_id']
        ?? $input['trx']
        ?? ''
    ));

    $status = strtoupper(trim((string)(
        $input['result']
        ?? $input['status']
        ?? ''
    )));

    $uuid = trim((string)(
        $input['uuid']
        ?? $input['purchaseId']
        ?? ''
    ));

    if ($trx === '') {
        log_cb('TRX_MISSING');
        out('TRX_MISSING', 400);
    }

    /* ================= UPDATE VTIGER PAYMENT ================= */

    try {

        $stmt = $pdo->prepare("
            UPDATE vtiger_payment
            SET
                payment_tks_status = 'PAID',
                payment_tks_callbackreceived = 1,
                payment_tks_callbackrawdata = :raw,
                payment_tks_transactionid = COALESCE(payment_tks_transactionid, :uuid)
            WHERE payment_tks_paymentno = :trx
        ");

        $stmt->execute([
            ':raw'  => $raw,
            ':uuid' => $uuid,
            ':trx'  => $trx
        ]);

        log_cb("PAYMENT_UPDATED: $trx");

    } catch (Throwable $e) {
        log_cb("PAYMENT_UPDATE_ERROR: ".$e->getMessage());
    }

    /* ================= LOAD PENDING ================= */

    $st = $pdo->prepare("
        SELECT *
        FROM m24_pending_package
        WHERE trx = ?
        LIMIT 1
    ");
    $st->execute([$trx]);
    $pending = $st->fetch();

    if (!$pending) {
        log_cb("PENDING_NOT_FOUND: $trx");
        out('OK');
    }

    if ($pending['status'] === 'DONE') {
        out('OK');
    }

    /* ================= SUCCESS ================= */

    $successStatuses = ['OK','SUCCESS','APPROVED','PAID','CAPTURED','COMPLETED'];
    $isSuccess = in_array($status, $successStatuses, true);

    if (!$isSuccess) {

        $pdo->prepare("
            UPDATE m24_pending_package
            SET status = 'ERROR', updated_at = NOW()
            WHERE trx = ?
        ")->execute([$trx]);

        log_cb("FAILED: $trx");
        out('OK');
    }

    /* ================= LOCK ================= */

    $lock = $pdo->prepare("
        UPDATE m24_pending_package
        SET status = 'PROCESSING'
        WHERE trx = ?
          AND status IN ('PENDING','PAID','ERROR')
    ");
    $lock->execute([$trx]);

    if ($lock->rowCount() === 0) {
        out('OK');
    }

    /* ================= CRM ================= */

    $CRM_URL       = $env['VTIGER_URL'];
    $CRM_USERNAME  = $env['VTIGER_USERNAME'];
    $CRM_ACCESSKEY = $env['VTIGER_ACCESS_KEY'];

    $challenge = json_decode(file_get_contents(
        $CRM_URL . '?operation=getchallenge&username=' . $CRM_USERNAME
    ), true);

    $accessKey = md5($challenge['result']['token'] . $CRM_ACCESSKEY);

    $login = vtiger_post($CRM_URL, [
        'operation' => 'login',
        'username'  => $CRM_USERNAME,
        'accessKey' => $accessKey,
    ]);

    $sessionId = $login['result']['sessionName'];

    $contactWsId = '12x' . ((int)$pending['contact_id']);

    /* ================= CREATE OPPORTUNITY ================= */

    $create = vtiger_post($CRM_URL, [
        'operation'   => 'create',
        'sessionName' => $sessionId,
        'elementType' => 'Potentials',
        'element'     => json_encode([
            'assigned_user_id' => '19x1',
            'potentialname'    => $trx,
            'contact_id'       => $contactWsId,
            'sales_stage'      => 'Closed Won',
            'closingdate'      => date('Y-m-d'),
            'description'      => "Kupovina paketa\nTRX: $trx",
        ], JSON_UNESCAPED_UNICODE),
    ]);

    $opportunityId = $create['result']['id'];

    $pdo->prepare("
        UPDATE m24_pending_package
        SET opportunity_id = ?, status = 'DONE', updated_at = NOW()
        WHERE trx = ?
    ")->execute([$opportunityId, $trx]);

    log_cb("DONE: $trx");

    out('OK');

} catch (Throwable $e) {

    log_cb("ERROR: " . $e->getMessage());
    out('OK');
}
