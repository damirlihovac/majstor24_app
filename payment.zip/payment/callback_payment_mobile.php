<?php
declare(strict_types=1);

header('Content-Type: application/json');

$pdo = new PDO(...); // isti kao prije

$data = $_REQUEST;

$trx = $data['merchantTransactionId'] ?? null;
$status = strtoupper($data['status'] ?? '');

if($status !== 'SUCCESS'){
    echo json_encode(['success'=>false]);
    exit;
}

/* FIND USER */
$stmt = $pdo->prepare("SELECT contact_id FROM m24_pending_payment WHERE trx=?");
$stmt->execute([$trx]);
$row = $stmt->fetch();

if(!$row){
    echo json_encode(['success'=>false]);
    exit;
}

$contactId = $row['contact_id'];

/* 🔥 OVDJE ZOVEŠ */
require_once __DIR__ . '/_ticket_creator.php';
// ili _package_creator.php

echo json_encode(['success'=>true]);<?php
declare(strict_types=1);

header('Content-Type: application/json');

$pdo = new PDO(...); // isti kao prije

$data = $_REQUEST;

$trx = $data['merchantTransactionId'] ?? null;
$status = strtoupper($data['status'] ?? '');

if($status !== 'SUCCESS'){
    echo json_encode(['success'=>false]);
    exit;
}

/* FIND USER */
$stmt = $pdo->prepare("SELECT contact_id FROM m24_pending_payment WHERE trx=?");
$stmt->execute([$trx]);
$row = $stmt->fetch();

if(!$row){
    echo json_encode(['success'=>false]);
    exit;
}

$contactId = $row['contact_id'];

/* 🔥 OVDJE ZOVEŠ */
require_once __DIR__ . '/_ticket_creator.php';
// ili _package_creator.php

echo json_encode(['success'=>true]);
