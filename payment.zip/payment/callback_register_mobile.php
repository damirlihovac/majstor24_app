<?php
declare(strict_types=1);

use PaymentGatewayJson\Client\Client;

require_once __DIR__ . '/../../placanje/php_sdk/PHPPaymentGatewayJson3.0.1/autoload.php';
require_once __DIR__ . '/_bankart_parser.php';

date_default_timezone_set('Europe/Sarajevo');

ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);

/* ================= LOG ================= */

function m24_log(string $message): void
{
    file_put_contents(
        '/var/log/majstor24/callback_register_mobile.log',
        '[' . date('c') . '] ' . $message . PHP_EOL,
        FILE_APPEND
    );
}

/* ================= HELPERS ================= */

function m24_ok(): void
{
    echo 'OK';
    exit;
}

function m24_get_next_crmid(PDO $pdo): int
{
    $pdo->exec("LOCK TABLES vtiger_crmentity_seq WRITE, vtiger_crmentity READ");

    try {
        $seq = (int)$pdo->query("SELECT id FROM vtiger_crmentity_seq")->fetchColumn();
        $max = (int)$pdo->query("SELECT MAX(crmid) FROM vtiger_crmentity")->fetchColumn();

        $newId = max($seq, $max + 1);

        $stmt = $pdo->prepare("UPDATE vtiger_crmentity_seq SET id = ?");
        $stmt->execute([$newId + 1]);

        $pdo->exec("UNLOCK TABLES");

        return $newId;
    } catch (Throwable $e) {
        try {
            $pdo->exec("UNLOCK TABLES");
        } catch (Throwable $unlockError) {
        }
        throw $e;
    }
}

/* ================= START ================= */

try {
    file_put_contents(
        '/var/log/majstor24/callback_hit.log',
        date('c') . " HIT\n",
        FILE_APPEND
    );

    $env = @parse_ini_file('/var/www/majstor24_env/core-api.env') ?: [];
    if (!$env) {
        m24_log('ENV_ERROR');
        m24_ok();
    }

    $pdo = new PDO(
        "mysql:host={$env['M24_DB_HOST']};dbname={$env['M24_DB_NAME']};charset=utf8mb4",
        $env['M24_DB_USER'],
        $env['M24_DB_PASS'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );

    $client = new Client(
        $env['BANKART_API_USER'] ?? '',
        $env['BANKART_API_PASSWORD'] ?? '',
        $env['BANKART_API_KEY'] ?? '',
        $env['BANKART_SHARED_SECRET'] ?? '',
        'EN'
    );

    $raw = file_get_contents('php://input') ?: '';

    file_put_contents(
        '/var/log/majstor24/callback_raw.log',
        date('c') . "\n" . $raw . "\n\n",
        FILE_APPEND
    );

    if ($raw === '') {
        m24_log('EMPTY_RAW');
        m24_ok();
    }

    try {
        $cb = $client->readCallback($raw);
        $data = $cb->toArray();
    } catch (Throwable $e) {
        m24_log('READ_CALLBACK_ERROR=' . $e->getMessage());
        m24_ok();
    }

    $parsed = bankart_parse($data);

    $status         = strtoupper(trim((string)($parsed['status'] ?? '')));
    $trx            = trim((string)($parsed['trx'] ?? ''));
    $uuid           = trim((string)($parsed['uuid'] ?? ''));
    $registrationId = trim((string)($parsed['registrationId'] ?? ''));
    $masked         = trim((string)($parsed['masked'] ?? '****'));
    $brand          = trim((string)($parsed['brand'] ?? 'CARD'));
    $email          = trim((string)($parsed['email'] ?? ''));
    $cardHolder     = trim((string)($parsed['cardHolder'] ?? ''));
    $contactId      = (int)($parsed['contactId'] ?? 0);

    m24_log("RAW_PARSED trx={$trx} status={$status} regId={$registrationId} contactFromPayload={$contactId}");

    if ($trx === '') {
        m24_log('MISSING_TRX');
        m24_ok();
    }

    if (!bankart_is_success($status)) {
        m24_log("NOT_SUCCESS trx={$trx} status={$status}");
        m24_ok();
    }

    if ($registrationId === '') {
        m24_log("NO_ADAPTER_REGISTRATION_ID trx={$trx}");
        m24_ok();
    }

    /* ================= CONTACT FROM PENDING ================= */

    $stmt = $pdo->prepare("
        SELECT contact_id
        FROM m24_pending_register
        WHERE trx = ?
        ORDER BY id DESC
        LIMIT 1
    ");
    $stmt->execute([$trx]);

    $pendingContactId = (int)$stmt->fetchColumn();

    if ($pendingContactId > 0) {
        $contactId = $pendingContactId;
    }

    if ($contactId <= 0 && preg_match('/^RG-(\d+)-/', $trx, $m)) {
        $contactId = (int)$m[1];
    }

    if ($contactId <= 0) {
        m24_log("NO_CONTACT_ID trx={$trx}");
        m24_ok();
    }

    $relatedTo = '12x' . $contactId;

    /* ================= NORMALIZE VALUES ================= */

    if ($cardHolder === '') {
        $cardHolder = trim((string)($data['returnData']['cardHolder'] ?? ''));
    }

    if ($brand === '') {
        $brand = 'CARD';
    }

    $brand = strtoupper($brand);

    $rawJson = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($rawJson === false) {
        $rawJson = '{}';
    }

    m24_log("UPSERT_START trx={$trx} contactId={$contactId} relatedTo={$relatedTo} regId={$registrationId} uuid={$uuid}");

    /* ================= EXISTING CARD CHECK ================= */

    $stmt = $pdo->prepare("
        SELECT paymentid
        FROM vtiger_payment
        WHERE payment_tks_bankardtransaction = ?
        LIMIT 1
    ");
    $stmt->execute([$registrationId]);

    $existingPaymentId = (int)$stmt->fetchColumn();

    if ($existingPaymentId > 0) {
        $stmt = $pdo->prepare("
            UPDATE vtiger_payment
            SET
                payment_tks_replatedto = ?,
                payment_tks_customeremail = ?,
                payment_tks_status = 'REGISTERED',
                payment_tks_maskedcardnumberpa = ?,
                payment_tks_cardholdername = ?,
                payment_tks_paymentmethodbrand = ?,
                payment_tks_paymentno = ?,
                payment_tks_transactionid = ?,
                payment_tks_callbackreceived = 1,
                payment_tks_callbackrawdata = ?,
                payment_tks_amount = '0.00',
                payment_tks_curency = 'BAM'
            WHERE paymentid = ?
        ");
        $stmt->execute([
            $relatedTo,
            $email,
            $masked,
            $cardHolder,
            $brand,
            $trx,
            $uuid,
            $rawJson,
            $existingPaymentId
        ]);

        m24_log("UPDATED_EXISTING paymentId={$existingPaymentId} trx={$trx}");
        m24_ok();
    }

    /* ================= INSERT NEW PAYMENT ================= */

    $paymentId = m24_get_next_crmid($pdo);

    file_put_contents(
        '/var/log/majstor24/register_mobile_callback.log',
        '[' . date('c') . "] INSERT paymentId={$paymentId} trx={$trx} contactId={$contactId} relatedTo={$relatedTo} regId={$registrationId}\n",
        FILE_APPEND
    );

    $stmt = $pdo->prepare("
        INSERT INTO vtiger_crmentity
        (
            crmid,
            smcreatorid,
            smownerid,
            modifiedby,
            setype,
            description,
            createdtime,
            modifiedtime,
            presence,
            deleted,
            label
        )
        VALUES
        (?, 1, 1, 1, 'Payment', '', NOW(), NOW(), 1, 0, ?)
    ");
    $stmt->execute([
        $paymentId,
        $cardHolder !== '' ? $cardHolder : $masked
    ]);

    $stmt = $pdo->prepare("
        INSERT INTO vtiger_payment
        (
            paymentid,
            payment_tks_replatedto,
            payment_tks_customeremail,
            payment_tks_status,
            payment_tks_maskedcardnumberpa,
            payment_tks_cardholdername,
            payment_tks_paymentmethodbrand,
            payment_tks_paymentno,
            payment_tks_transactionid,
            payment_tks_bankardtransaction,
            payment_tks_amount,
            payment_tks_curency,
            payment_tks_callbackreceived,
            payment_tks_callbackrawdata
        )
        VALUES
        (?, ?, ?, 'REGISTERED', ?, ?, ?, ?, ?, ?, '0.00', 'BAM', 1, ?)
    ");
    $stmt->execute([
        $paymentId,
        $relatedTo,
        $email,
        $masked,
        $cardHolder,
        $brand,
        $trx,
        $uuid,
        $registrationId,
        $rawJson
    ]);

    m24_log("INSERTED_NEW paymentId={$paymentId} trx={$trx} regId={$registrationId}");
    m24_ok();

} catch (Throwable $e) {
    m24_log('FATAL_ERROR=' . $e->getMessage());
    m24_ok();
}
