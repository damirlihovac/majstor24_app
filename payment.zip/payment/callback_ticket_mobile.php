<?php
declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/callback_ticket_mobile_error.log');
error_reporting(E_ALL);

require_once __DIR__ . '/_ticket_creator.php';

require_once __DIR__ . '/_bankart_parser.php';

$parsed = bankart_parse($payload);

$trx    = $parsed['trx'];
$status = $parsed['status'];
$uuid   = $parsed['uuid'];


/* ========================================================== */

function cb_out(string $body, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: text/plain; charset=utf-8');
    echo $body;
    exit;
}

function cb_log(string $msg, array $ctx = []): void {
    $line = '[callback_ticket_mobile] ' . $msg;
    if (!empty($ctx)) {
        $line .= ' | ' . json_encode($ctx, JSON_UNESCAPED_UNICODE);
    }
    error_log($line);
}

function find_first(array $data, array $keys, $default = null) {
    foreach ($keys as $k) {
        if (array_key_exists($k, $data) && $data[$k] !== '' && $data[$k] !== null) {
            return $data[$k];
        }
    }
    return $default;
}

function is_success_status(string $status): bool {
    $status = strtoupper(trim($status));
    return in_array($status, [
        'SUCCESS','APPROVED','OK','PAID','CAPTURED','COMPLETED','AUTHORISED','AUTHORIZED'
    ], true);
}

try {

    /* ================= ENV ================= */

    $env = @parse_ini_file('/var/www/majstor24_env/core-api.env') ?: [];
    if (!$env) {
        cb_log('ENV_NOT_LOADED');
        cb_out('ENV_NOT_LOADED', 500);
    }

    /* ================= DB ================= */

    $pdo = new PDO(
        "mysql:host={$env['M24_DB_HOST']};dbname={$env['M24_DB_NAME']};charset=utf8mb4",
        $env['M24_DB_USER'],
        $env['M24_DB_PASS'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );

    /* ================= RAW ================= */

    $raw = file_get_contents('php://input') ?: '';
    $json = json_decode($raw, true);
    $payload = is_array($json) ? $json : [];

    cb_log('CALLBACK_RECEIVED', [
        'payload' => $payload,
        'raw'     => $raw,
    ]);

    /* ================= EXTRACT ================= */

    $trx = trim((string) find_first($payload, [
        'merchantTransactionId','merchant_trx_id','trx','tx'
    ], ''));

    $statusRaw = strtoupper(trim((string) find_first($payload, [
        'result','status','paymentStatus'
    ], '')));

    $uuid = trim((string) find_first($payload, [
        'uuid','purchaseId'
    ], ''));

    if ($trx === '') {
        cb_log('TRX_MISSING');
        cb_out('TRX_MISSING', 400);
    }

    /* ================= FIND PENDING ================= */

    $st = $pdo->prepare("
        SELECT id, contact_id, ticket_id, payload_json
        FROM m24_pending_ticket
        WHERE merchant_trx_id = ?
        LIMIT 1
    ");
    $st->execute([$trx]);
    $pending = $st->fetch();

    if (!$pending) {
        cb_log('PENDING_NOT_FOUND', ['trx'=>$trx]);
        cb_out('OK', 200);
    }

    $pendingId = (int)$pending['id'];
    $contactId = (int)$pending['contact_id'];

    /* ================= IDEMPOTENCY ================= */

    if (!empty($pending['ticket_id'])) {
        cb_log('ALREADY_CREATED', ['trx'=>$trx]);
        cb_out('OK', 200);
    }

    /* ================= STATUS ================= */

    if (!is_success_status($statusRaw)) {

        $pdo->prepare("
            UPDATE m24_pending_ticket
            SET status = ?, updated_at = NOW()
            WHERE id = ?
        ")->execute([
            $statusRaw ?: 'FAILED',
            $pendingId
        ]);

        cb_log('PAYMENT_FAILED', ['trx'=>$trx,'status'=>$statusRaw]);
        cb_out('OK', 200);
    }

    /* ================= VTIGER PAYMENT ================= */

    try {

        $stmtPayment = $pdo->prepare("
            UPDATE vtiger_payment
            SET
                payment_tks_status = 'PAID',
                payment_tks_callbackreceived = 1,
                payment_tks_callbackrawdata = :raw,
                payment_tks_transactionid = COALESCE(payment_tks_transactionid, :uuid)
            WHERE payment_tks_paymentno = :trx
        ");

        $stmtPayment->execute([
            ':raw'  => $raw,
            ':uuid' => $uuid,
            ':trx'  => $trx
        ]);

        cb_log('VTIGER_PAYMENT_UPDATED', ['trx'=>$trx]);

    } catch (Throwable $e) {
        cb_log('VTIGER_UPDATE_ERROR', ['error'=>$e->getMessage()]);
    }

    /* ================= UPDATE PENDING ================= */

    $payloadJson = json_decode((string)$pending['payload_json'], true) ?: [];

    $payloadJson['bankart_callback'] = [
        'status' => $statusRaw,
        'uuid'   => $uuid,
        'time'   => date('c')
    ];

    $pdo->prepare("
        UPDATE m24_pending_ticket
        SET payload_json = ?, status = 'PAID', updated_at = NOW()
        WHERE id = ?
    ")->execute([
        json_encode($payloadJson),
        $pendingId
    ]);

    /* ================= CREATE TICKET ================= */

    try {

        $res = create_ticket_from_pending($pdo, $contactId, $trx);

        cb_log('TICKET_RESULT', $res ?? []);

        $ticketId = $res['ticket_ws_id'] ?? null;

        $pdo->prepare("
            UPDATE m24_pending_ticket
            SET status = 'DONE', ticket_id = ?
            WHERE id = ?
        ")->execute([$ticketId, $pendingId]);

    } catch (Throwable $e) {
        cb_log('TICKET_ERROR', ['error'=>$e->getMessage()]);
    }

    cb_out('OK', 200);

} catch (Throwable $e) {

    cb_log('FATAL', [
        'msg'=>$e->getMessage(),
        'line'=>$e->getLine()
    ]);

    cb_out('ERROR', 500);
}
