<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

$env = @parse_ini_file('/var/www/majstor24_env/core-api.env') ?: [];

$pdo = new PDO(
    "mysql:host={$env['M24_DB_HOST']};dbname={$env['M24_DB_NAME']};charset=utf8mb4",
    $env['M24_DB_USER'],
    $env['M24_DB_PASS'],
    [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]
);

$trx = trim((string)($_GET['trx'] ?? ''));
if ($trx === '') {
    echo json_encode(['success' => false, 'message' => 'trx missing']);
    exit;
}

$st = $pdo->prepare("
    SELECT status, opportunity_id, updated_at
    FROM m24_pending_package
    WHERE trx = ?
    LIMIT 1
");
$st->execute([$trx]);
$row = $st->fetch();

if (!$row) {
    echo json_encode(['success' => false, 'message' => 'not found']);
    exit;
}

/*
status:
PENDING | PAID | PROCESSING | DONE | ERROR
*/

echo json_encode([
    'success'         => true,
    'trx'             => $trx,
    'status'          => $row['status'],
    'opportunity_id'  => $row['opportunity_id'],
    'updated_at'      => $row['updated_at'],
]);
