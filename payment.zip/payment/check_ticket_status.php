<?php
declare(strict_types=1);

header("Content-Type: application/json; charset=utf-8");

require_once __DIR__.'/../common/db.php';

function respond($data){
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

$trx = $_GET['trx'] ?? '';

if (!$trx) {
    respond([
        "success" => false,
        "status" => "MISSING_TRX"
    ]);
}

$pdo = db();

$stmt = $pdo->prepare("
SELECT status, ticket_id
FROM m24_pending_ticket
WHERE merchant_trx_id = ?
LIMIT 1
");

$stmt->execute([$trx]);
$row = $stmt->fetch();

if (!$row) {
    respond([
        "success" => false,
        "status" => "NOT_FOUND"
    ]);
}

/* ======================================
   🔥 STANDARDIZACIJA STATUSA
====================================== */

$status = strtoupper(trim($row['status'] ?? ''));

/*
DB → FRONTEND
-----------------------
CREATED     → DONE
DONE        → DONE
PAID        → PROCESSING
PENDING     → PROCESSING
ERROR       → ERROR
*/

/* ✅ ZAVRŠENO */
if ($status === 'DONE' || $status === 'CREATED') {
    respond([
        "success" => true,
        "status" => "DONE",
        "entity_id" => $row['ticket_id'] ?? null
    ]);
}

/* ⏳ U TOKU */
if ($status === 'PENDING' || $status === 'PAID') {
    respond([
        "success" => true,
        "status" => "PROCESSING"
    ]);
}

/* ❌ GREŠKA */
if ($status === 'ERROR') {
    respond([
        "success" => true,
        "status" => "ERROR"
    ]);
}

/* fallback */
respond([
    "success" => true,
    "status" => "PROCESSING"
]);
