<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

ini_set('display_errors','0');
ini_set('log_errors','1');
ini_set('error_log', __DIR__ . '/create_payment_intent_error.log');
error_reporting(E_ALL);

function respond(int $code, array $data){
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function bearer(): ?string
{
    $h = getallheaders();
    $auth = $h['Authorization'] ?? $h['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? null;
    if(!$auth) return null;

    if(preg_match('/Bearer\s+(.*)$/i',$auth,$m)){
        return trim($m[1]);
    }

    return null;
}

$vtigerConfig = '/var/www/html/crmmajstor24/config.inc.php';

if(!file_exists($vtigerConfig)){
    respond(500,['success'=>false,'message'=>'CRM_CONFIG_NOT_FOUND']);
}

require_once $vtigerConfig;

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try{
    $db = new mysqli(
        $dbconfig['db_server'],
        $dbconfig['db_username'],
        $dbconfig['db_password'],
        $dbconfig['db_name']
    );
    $db->set_charset('utf8mb4');
}catch(Throwable $e){
    respond(500,['success'=>false,'message'=>'DB_CONNECT_ERROR']);
}

$token = bearer();
if(!$token){
    respond(401,['success'=>false,'message'=>'TOKEN_MISSING']);
}

$stmt = $db->prepare("
SELECT cd.contactid
FROM vtiger_contactdetails cd
INNER JOIN vtiger_crmentity ce ON ce.crmid = cd.contactid
WHERE ce.deleted=0 AND cd.api_token=?
LIMIT 1
");
$stmt->bind_param("s",$token);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();
$stmt->close();

if(!$user){
    respond(401,['success'=>false,'message'=>'TOKEN_INVALID']);
}

$raw = file_get_contents("php://input");
$data = json_decode($raw,true);

if(!is_array($data)){
    respond(400,['success'=>false,'message'=>'INVALID_JSON']);
}

$trx = $data['merchant_trx_id'] ?? null;

if(!$trx){
    respond(400,['success'=>false,'message'=>'MISSING_TRX']);
}

$stmt = $db->prepare("
SELECT id, payload_json
FROM m24_pending_ticket
WHERE merchant_trx_id=?
LIMIT 1
");

$stmt->bind_param("s",$trx);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$stmt->close();

if(!$row){
    respond(404,['success'=>false,'message'=>'PENDING_NOT_FOUND']);
}

$payload = json_decode($row['payload_json'],true);
$cijena  = $payload['request']['cijena'] ?? 0;

if($cijena<=0){
    respond(400,['success'=>false,'message'=>'INVALID_AMOUNT']);
}

respond(200,[
"success"=>true,
"payment_intent"=>[
"merchant_trx_id"=>$trx,
"amount"=>$cijena,
"currency"=>"BAM"
]
]);
