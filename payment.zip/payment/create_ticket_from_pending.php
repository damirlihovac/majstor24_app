<?php
declare(strict_types=1);

function createTicketFromPending(string $trx): string
{

/* ===============================
   DB CONFIG
================================ */

require '/var/www/html/crmmajstor24/config.inc.php';

$db = new mysqli(
    $dbconfig['db_server'],
    $dbconfig['db_username'],
    $dbconfig['db_password'],
    $dbconfig['db_name']
);

if ($db->connect_error) {
    throw new Exception("DB_CONNECT_ERROR");
}

$db->set_charset("utf8mb4");

/* ===============================
   LOAD ENV
================================ */

$env = parse_ini_file('/var/www/majstor24_env/core-api.env');

$username  = $env['VTIGER_USERNAME'];
$accessKey = $env['VTIGER_ACCESS_KEY'];
$endpoint  = $env['VTIGER_URL'];

/* ===============================
   LOAD PENDING
================================ */

$stmt = $db->prepare("
SELECT contact_id,email,payload_json
FROM m24_pending_ticket
WHERE merchant_trx_id=?
LIMIT 1
");

$stmt->bind_param("s",$trx);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$stmt->close();

if(!$row){
    throw new Exception("PENDING_NOT_FOUND");
}

$contactId = $row['contact_id'];

$payload = json_decode($row['payload_json'],true);

$request = $payload['request'];
$termin  = $payload['termin'];

$adresa   = $request['adresa'] ?? '';
$ptt      = $request['ptt'] ?? '';
$mjesto   = $request['mjesto'] ?? '';
$usluga   = $request['usluga'] ?? '';
$podgrupa = $request['podgrupa'] ?? '';
$napomene = $request['napomene'] ?? '';
$cijena   = $request['cijena'] ?? 0;

$datum    = $termin['datum'] ?? '';
$vrijeme  = $termin['vrijeme'] ?? '';

/* ===============================
   VTIGER LOGIN
================================ */

$ch = curl_init($endpoint."?operation=getchallenge&username=".$username);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
$res = curl_exec($ch);
curl_close($ch);

$data = json_decode($res,true);

if(!$data['success']){
    throw new Exception("VTIGER_CHALLENGE_FAILED");
}

$challenge = $data['result']['token'];

$loginKey = md5($challenge.$accessKey);

$post = [
"operation"=>"login",
"username"=>$username,
"accessKey"=>$loginKey
];

$ch = curl_init($endpoint);
curl_setopt($ch,CURLOPT_POST,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$post);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);

$res = curl_exec($ch);
curl_close($ch);

$data = json_decode($res,true);

if(!$data['success']){
    throw new Exception("VTIGER_LOGIN_FAILED");
}

$session = $data['result']['sessionName'];

/* ===============================
   CREATE TICKET
================================ */

$title = "Asistencija - ".$usluga;

$description =
"Adresa: ".$adresa."\n".
"PTT: ".$ptt."\n".
"Mjesto: ".$mjesto."\n".
"Usluga: ".$usluga."\n".
"Podgrupa: ".$podgrupa."\n".
"Datum: ".$datum."\n".
"Vrijeme: ".$vrijeme."\n".
"Napomene: ".$napomene."\n".
"Cijena: ".$cijena;

$element = [
"ticket_title"=>$title,
"description"=>$description,
"contact_id"=>"12x".$contactId,
"assigned_user_id"=>"19x1",
"ticketstatus"=>"Open",
"ticketpriorities"=>"Normal"
];

$post = [
"operation"=>"create",
"sessionName"=>$session,
"elementType"=>"HelpDesk",
"element"=>json_encode($element)
];

$ch = curl_init($endpoint);
curl_setopt($ch,CURLOPT_POST,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$post);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);

$res = curl_exec($ch);
curl_close($ch);

$data = json_decode($res,true);

if(!$data['success']){
    throw new Exception("VTIGER_CREATE_FAILED");
}

$ticketWsId = $data['result']['id'];

$parts = explode("x",$ticketWsId);

return $parts[1];

}
