<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

session_start();

require_once __DIR__ . '/../config.php';

$contactId = $_SESSION['contactid'] ?? null;

if (!$contactId) {
    echo json_encode([
        'success' => false,
        'message' => 'NO_SESSION'
    ]);
    exit;
}

$input = json_decode(file_get_contents("php://input"), true);
$cardId = $input['cardId'] ?? null;

if (!$cardId) {
    echo json_encode([
        'success' => false,
        'message' => 'MISSING_CARD_ID'
    ]);
    exit;
}

try {

    // 👉 Ovdje ide tvoj CRM update (primjer VTiger WS)
    $data = [
        'id' => $cardId,
        'cf_status' => 'DEACTIVATED'
    ];

    $result = vtiger_update_record('BankartPayment', $data);

    echo json_encode([
        'success' => true
    ]);

} catch (Throwable $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
