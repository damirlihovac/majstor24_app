<?php
declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors','0');
ini_set('log_errors','1');
ini_set('error_log','/var/log/majstor24/delete_card_mobile.log');

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__.'/../../common/db.php';

/* ================= HELPERS ================= */

function respond(int $code,array $data){
    http_response_code($code);
    echo json_encode($data,JSON_UNESCAPED_UNICODE);
    exit;
}

function bearer(): ?string {

    $h = getallheaders();

    $auth =
        $h['Authorization']
        ?? $h['authorization']
        ?? $_SERVER['HTTP_AUTHORIZATION']
        ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
        ?? null;

    if(!$auth) return null;

    if(preg_match('/Bearer\s+(.*)$/i',$auth,$m)){
        return trim($m[1]);
    }

    return null;
}

/* ================= MAIN ================= */

try {

$pdo = db();

/* ================= TOKEN ================= */

$token = bearer();

if(!$token){
    respond(401,[
        'success'=>false,
        'code'=>'TOKEN_MISSING'
    ]);
}

/* ================= USER ================= */

$stmt = $pdo->prepare("
SELECT contactid
FROM vtiger_contactdetails
WHERE api_token = :token
LIMIT 1
");

$stmt->execute([':token'=>$token]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$user){
    respond(401,[
        'success'=>false,
        'code'=>'INVALID_TOKEN'
    ]);
}

$contactId   = (int)$user['contactid'];
$contactWsId = '12x'.$contactId;

/* ================= INPUT ================= */

$input = json_decode(file_get_contents("php://input"), true);

$cardId = $input['card_id'] ?? null;

if(!$cardId){
    respond(400,[
        'success'=>false,
        'code'=>'CARD_ID_MISSING'
    ]);
}

/* ================= CHECK OWNERSHIP ================= */

$stmt = $pdo->prepare("
SELECT paymentid
FROM vtiger_payment
WHERE paymentid = :id
AND payment_tks_replatedto = :contact
LIMIT 1
");

$stmt->execute([
    ':id'=>$cardId,
    ':contact'=>$contactWsId
]);

$card = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$card){
    respond(404,[
        'success'=>false,
        'code'=>'CARD_NOT_FOUND'
    ]);
}

/* ================= UPDATE (SOFT DELETE) ================= */

$stmt = $pdo->prepare("
UPDATE vtiger_payment
SET payment_tks_status = 'DELETED'
WHERE paymentid = :id
LIMIT 1
");

$stmt->execute([
    ':id'=>$cardId
]);

respond(200,[
    'success'=>true
]);

}
catch(Throwable $e){

error_log('DELETE_CARD_ERROR: '.$e->getMessage());

respond(500,[
    'success'=>false,
    'code'=>'SERVER_ERROR'
]);

}
