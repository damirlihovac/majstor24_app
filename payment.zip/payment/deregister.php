<?php
declare(strict_types=1);

/**
 * Majstor24 – Deregister card (Vtiger Payment)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header("Content-Type: application/json; charset=utf-8");

// ======================================================
// CONFIG
// ======================================================
$LOG_FILE      = '/var/log/majstor24/deregister_debug.log';
$PAYMENT_WS_ID = '36'; // Payment module tabid

$log = function (string $msg) use ($LOG_FILE): void {
    file_put_contents($LOG_FILE, date('c') . " " . $msg . "\n", FILE_APPEND);
};

$log(">>> DEREGISTER START FILE=" . __FILE__ . " <<<");

// ======================================================
// 1) HTTP method
// ======================================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Nevažeći zahtjev']);
    exit;
}

// ======================================================
// 2) Auth session
// ======================================================
$email = $_SESSION['email'] ?? null;
if (!$email) {
    echo json_encode(['success' => false, 'message' => 'Korisnik nije prijavljen']);
    exit;
}

// ======================================================
// 3) Input
// ======================================================
$raw = file_get_contents('php://input') ?: '';
$log("RAW: " . $raw);

$data = json_decode($raw, true) ?: $_POST;

$incoming = $data['paymentid']
    ?? $data['bankartpaymentid']
    ?? $data['paymentId']
    ?? $data['id']
    ?? null;

if (is_string($incoming)) {
    $incoming = trim($incoming);
}

if ($incoming !== null && ctype_digit((string)$incoming)) {
    $incoming = $PAYMENT_WS_ID . 'x' . $incoming;
}

$log("PARSED paymentid: " . var_export($incoming, true));

if (!$incoming || !preg_match('/^\d+x\d+$/', (string)$incoming)) {
    echo json_encode(['success' => false, 'message' => 'Nevažeći paymentid']);
    exit;
}

$paymentWsId = (string)$incoming;

// ======================================================
// 4) ENV
// ======================================================
$env = parse_ini_file('/var/www/majstor24_env/core-api.env') ?: [];

$CRM_URL       = trim($env['VTIGER_URL'] ?? '');
$CRM_USERNAME  = trim($env['VTIGER_USERNAME'] ?? '');
$CRM_ACCESSKEY = trim($env['VTIGER_ACCESS_KEY'] ?? '');

if (!$CRM_URL || !$CRM_USERNAME || !$CRM_ACCESSKEY) {
    echo json_encode(['success' => false, 'message' => 'CRM konfiguracija nedostaje']);
    exit;
}

$CRM_URL = rtrim($CRM_URL, '/');
if (!str_ends_with($CRM_URL, 'webservice.php')) {
    $CRM_URL .= '/webservice.php';
}

$log("CRM_URL=$CRM_URL USER=$CRM_USERNAME");

// ======================================================
// 5) getchallenge
// ======================================================
$ch = curl_init($CRM_URL . '?operation=getchallenge&username=' . urlencode($CRM_USERNAME));
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 10,
]);
$challengeRaw = curl_exec($ch);
curl_close($ch);

$log("CHALLENGE RAW: " . $challengeRaw);

$challenge = json_decode($challengeRaw ?: '', true);
if (empty($challenge['success'])) {
    echo json_encode(['success' => false, 'message' => 'CRM getchallenge neuspješan']);
    exit;
}

$token = $challenge['result']['token'];
$accessHash = md5($token . $CRM_ACCESSKEY);

// ======================================================
// 6) login
// ======================================================
$ch = curl_init($CRM_URL);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_TIMEOUT        => 10,
    CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
    CURLOPT_POSTFIELDS     => http_build_query([
        'operation' => 'login',
        'username'  => $CRM_USERNAME,
        'accessKey' => $accessHash
    ])
]);
$loginRaw = curl_exec($ch);
curl_close($ch);

$log("LOGIN RAW: " . $loginRaw);

$login = json_decode($loginRaw ?: '', true);
if (empty($login['success'])) {
    echo json_encode(['success' => false, 'message' => 'CRM login neuspješan']);
    exit;
}

$sessionId = $login['result']['sessionName'];
$log("SESSIONID = " . $sessionId);

// ======================================================
// 7) update (DEACTIVATE)
// ======================================================
$update = [
    'id'                 => $paymentWsId,
    'assigned_user_id'   => '19x1',
    'payment_tks_status' => 'DEACTIVATED'
];

$ch = curl_init($CRM_URL);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_TIMEOUT        => 10,
    CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
    CURLOPT_POSTFIELDS     => http_build_query([
        'operation'   => 'update',
        'sessionName' => $sessionId,
        'element'     => json_encode($update)
    ])
]);
$updateRaw = curl_exec($ch);
curl_close($ch);

$log("UPDATE RAW: " . $updateRaw);

$updateRes = json_decode($updateRaw ?: '', true);
if (empty($updateRes['success'])) {
    echo json_encode(['success' => false, 'message' => 'Deaktivacija kartice nije uspjela']);
    exit;
}

// ======================================================
// 8) SUCCESS
// ======================================================
$log("OK deactivated: $paymentWsId email=$email");

echo json_encode([
    'success' => true,
    'message' => 'Kartica je uspješno deaktivirana'
]);
exit;
