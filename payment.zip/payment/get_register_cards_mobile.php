<?php
declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors','0');
ini_set('log_errors','1');
ini_set('error_log','/var/log/majstor24/get_registered_cards_error.log');

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__.'/../../common/db.php';

/* ================= HELPERS ================= */

function respond(int $code,array $data){
    http_response_code($code);
    echo json_encode($data,JSON_UNESCAPED_UNICODE);
    exit;
}

function bearer(): ?string {

    $h = function_exists('getallheaders') ? getallheaders() : [];

    $auth =
        $h['Authorization']
        ?? $h['authorization']
        ?? $_SERVER['HTTP_AUTHORIZATION']
        ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
        ?? null;

    if(!$auth) return null;

    if(preg_match('/Bearer\s+(.*)$/i',$auth,$m)){
        return trim($m[1]);
    }

    return null;
}

try{

$pdo = db();

/* =====================================================
   TOKEN
===================================================== */

$token = bearer();

if(!$token){

respond(401,[
    'success'=>false,
    'code'=>'TOKEN_MISSING'
]);

}

/* =====================================================
   USER
===================================================== */

$stmt = $pdo->prepare("
SELECT contactid, email
FROM vtiger_contactdetails
WHERE api_token = :token
LIMIT 1
");

$stmt->execute([
':token'=>$token
]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$user){

respond(401,[
    'success'=>false,
    'code'=>'INVALID_TOKEN'
]);

}

$contactId   = (int)$user['contactid'];
$contactWsId = '12x' . $contactId;
$email       = $user['email'];

/* =====================================================
   FETCH CARDS
===================================================== */

$stmt = $pdo->prepare("
SELECT
    paymentid,
    payment_tks_bankardtransaction AS registration_id,
    payment_tks_maskedcardnumberpa AS masked,
    payment_tks_paymentmethodbrand AS brand,
    payment_tks_cardholdername AS holder
FROM vtiger_payment
WHERE
    payment_tks_status = 'REGISTERED'
    AND paymentno IS NOT NULL
    AND payment_tks_bankardtransaction IS NOT NULL
    AND payment_tks_replatedto = :contact
ORDER BY paymentid DESC
");

$stmt->execute([
    ':contact'=>$contactWsId,
    ':email'=>$email
]);

$cards = [];

while($row = $stmt->fetch(PDO::FETCH_ASSOC)){

$cards[] = [

'id'          => (int)$row['paymentid'],                 // koristi se za backend lookup
'registrationId' => $row['registration_id'],             // 🔥 COF token (ako zatreba)
'maskedCard'  => $row['masked'],
'brand'       => $row['brand'],
'cardHolder'  => $row['holder']

];

}

/* =====================================================
   RESPONSE
===================================================== */

respond(200,[

'success'=>true,
'cards'=>$cards

]);

}
catch(Throwable $e){

error_log('CARDS_API_ERROR: '.$e->getMessage());

respond(500,[

'success'=>false,
'code'=>'SERVER_ERROR'

]);

}
