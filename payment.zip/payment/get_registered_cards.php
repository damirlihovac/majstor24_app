<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', '/var/log/majstor24/get_cards_error.log');

// ============================================================
// 1️⃣ UČITAJ ISTI ENV KAO PROFIL
// ============================================================
$env = @parse_ini_file('/var/www/majstor24_env/core-api.env');

if (!$env) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'ENV not loaded']);
    exit;
}

// ============================================================
// 2️⃣ PDO – IDENTIČNO KAO U PROFILU
// ============================================================
try {
    $pdo = new PDO(
        "mysql:host={$env['M24_DB_HOST']};dbname={$env['M24_DB_NAME']};charset=utf8mb4",
        $env['M24_DB_USER'],
        $env['M24_DB_PASS'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (Throwable $e) {
    error_log('PDO ERROR: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'DB error']);
    exit;
}

// ============================================================
// 3️⃣ PROVJERA SESIJE
// ============================================================
$email = $_SESSION['email'] ?? null;
if (!$email) {
    echo json_encode(['success' => false, 'error' => 'No email in session']);
    exit;
}

// ============================================================
// 4️⃣ ISTI SQL KAO PROFIL
// ============================================================
$sql = "
    SELECT
        p.paymentid,
        p.payment_tks_maskedcardnumberpa,
        p.payment_tks_cardholdername,
        p.payment_tks_paymentmethodbrand,
        p.payment_tks_status
    FROM vtiger_payment p
    INNER JOIN vtiger_crmentity e ON e.crmid = p.paymentid
    WHERE e.deleted = 0
      AND p.payment_tks_customeremail = :email
      AND p.payment_tks_status = 'REGISTERED'
    ORDER BY e.createdtime DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute(['email' => $email]);

$cards = [];
foreach ($stmt->fetchAll() as $row) {
    $cards[] = [
        'id'         => $row['paymentid'],
        'maskedCard' => $row['payment_tks_maskedcardnumberpa'],
        'cardHolder' => $row['payment_tks_cardholdername'],
        'brand'      => $row['payment_tks_paymentmethodbrand'],
        'status'     => $row['payment_tks_status']
    ];
}

echo json_encode([
    'success' => true,
    'cards'   => $cards
], JSON_UNESCAPED_UNICODE);
