<?php $trx = $_GET['tx'] ?? ''; ?>
<script>
window.onload = function () {
    window.location.href = "majstor24://payment-result?status=error&type=register&tx=<?php echo urlencode($trx); ?>";
};
</script>
