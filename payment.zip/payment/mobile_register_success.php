<?php
declare(strict_types=1);

$trx = $_GET['trx'] ?? $_GET['tx'] ?? '';

if (!$trx) {
    echo "Missing TRX";
    exit;
}

/* =====================================
   🔥 POZOVI CALLBACK RUČNO
===================================== */

$callbackUrl = "https://majstor24.ba/api/payment/callback_register_mobile.php?trx="
               . urlencode($trx) . "&status=SUCCESS";

$ch = curl_init($callbackUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

/* LOG */
file_put_contents('/var/log/majstor24/register_success_debug.log',
    date('c') . " TRX=$trx RESPONSE=$response\n",
    FILE_APPEND
);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Success</title>

<script>
/* =====================================
   🔥 GLAVNI REDIRECT (APP DEEP LINK)
===================================== */
setTimeout(function () {
    window.location.href = "majstor24://payment-result?status=success&trx=<?php echo urlencode($trx); ?>";
}, 500);

/* =====================================
   🔥 FALLBACK (AKO APP NE PRESRETNE)
===================================== */
setTimeout(function () {
    window.location.href = "https://majstor24.ba";
}, 4000);
</script>

</head>
<body>
Uspješno, vraćamo vas u aplikaciju...
</body>
</html>
