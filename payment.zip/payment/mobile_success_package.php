<?php declare(strict_types=1);

$trx = $_GET['trx'] ?? '';

if (!$trx) {
    echo "INVALID_TRX";
    exit;
}

/* 🔥 FORCE CALLBACK */
file_get_contents(
    "https://majstor24.ba/api/payment/callback_package_mobile.php?merchantTransactionId=$trx&result=OK"
);

/* REDIRECT NA APP */
header("Location: majstor24://payment-success?status=success&trx=".$trx);
exit;
