<?php
declare(strict_types=1);

header("Content-Type: text/html; charset=utf-8");

/*
Bankart vraća na ovaj URL nakon plaćanja.

Mi samo vraćamo korisnika u aplikaciju:
majstor24://payment-result?tx=TRX
*/

$tx =
    $_GET['trx']
    ?? $_GET['tx']
    ?? $_GET['merchantTransactionId']
    ?? $_GET['merchantTxnId']
    ?? $_GET['transactionId']
    ?? '';

$uuid = $_GET['uuid'] ?? '';

if (!$tx) {
    echo "<h2>Greška: Nedostaje trx.</h2>";
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Obrada plaćanja</title>

<script>

function redirectToApp() {

    var tx = "<?php echo htmlspecialchars($tx, ENT_QUOTES, 'UTF-8'); ?>";
    var uuid = "<?php echo htmlspecialchars($uuid, ENT_QUOTES, 'UTF-8'); ?>";

    var url = "majstor24://payment-result?tx=" + encodeURIComponent(tx);

    if (uuid) {
        url += "&uuid=" + encodeURIComponent(uuid);
    }

    window.location.href = url;

    setTimeout(function(){
        window.close();
    },500);
}

window.onload = redirectToApp;

</script>

</head>

<body>

<h2>Obrada plaćanja...</h2>

</body>
</html>
