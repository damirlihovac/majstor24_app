<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

ini_set('display_errors','0');
ini_set('log_errors','1');
ini_set('error_log', __DIR__.'/start_bankart_transaction_error.log');
error_reporting(E_ALL);

require_once __DIR__ . '/../../placanje/php_sdk/PHPPaymentGatewayJson3.0.1/autoload.php';

use PaymentGatewayJson\Client\Client;
use PaymentGatewayJson\Client\Transaction\Debit;
use PaymentGatewayJson\Client\Data\Customer;

function m24_json(array $arr, int $code = 200): void {
    http_response_code($code);
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit;
}

try {

    /* ================= ENV ================= */

    $env = @parse_ini_file('/var/www/majstor24_env/core-api.env') ?: [];
    if (!$env) {
        throw new Exception('ENV_NOT_LOADED');
    }

    /* ================= DB ================= */

    $pdo = new PDO(
        "mysql:host={$env['M24_DB_HOST']};dbname={$env['M24_DB_NAME']};charset=utf8mb4",
        $env['M24_DB_USER'],
        $env['M24_DB_PASS'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );

    /* ================= AUTH ================= */

    $headers = function_exists('getallheaders') ? getallheaders() : [];

    $authHeader =
        $headers['Authorization']
        ?? $headers['authorization']
        ?? $_SERVER['HTTP_AUTHORIZATION']
        ?? '';

    if (!preg_match('/Bearer\s+(\S+)/i', $authHeader, $m)) {
        m24_json(['success'=>false,'message'=>'TOKEN_MISSING'],401);
    }

    $token = trim($m[1]);

    /* ================= LOAD USER ================= */

    $stmt = $pdo->prepare("
        SELECT
            cd.contactid,
            cd.email,
            cd.firstname,
            cd.lastname,
            ca.mailingstreet,
            ca.mailingzip,
            ca.mailingcity
        FROM vtiger_contactdetails cd
        LEFT JOIN vtiger_contactaddress ca
            ON cd.contactid = ca.contactaddressid
        WHERE cd.api_token=?
        LIMIT 1
    ");

    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if (!$user) {
        m24_json(['success'=>false,'message'=>'INVALID_TOKEN'],401);
    }

    $contactId = (int)$user['contactid'];
    $email     = (string)($user['email'] ?? '');

    /* ================= INPUT ================= */

    $input = json_decode(file_get_contents('php://input'), true) ?: [];

    $merchantTrxId = trim((string)($input['merchant_trx_id'] ?? $input['trx'] ?? ''));
    $cardId        = (int)($input['card_id'] ?? 0);

    if ($merchantTrxId === '') {
        m24_json(['success'=>false,'message'=>'TRX_MISSING'],400);
    }

    if ($cardId <= 0) {
        m24_json(['success'=>false,'message'=>'CARD_MISSING'],400);
    }

    /* ================= LOAD PENDING ================= */

    $stmt = $pdo->prepare("
        SELECT id, contact_id, payload_json, status, ticket_id
        FROM m24_pending_ticket
        WHERE merchant_trx_id=? AND contact_id=?
        ORDER BY id DESC
        LIMIT 1
    ");

    $stmt->execute([$merchantTrxId, $contactId]);
    $pending = $stmt->fetch();

    if (!$pending) {
        m24_json(['success'=>false,'message'=>'PENDING_NOT_FOUND'],404);
    }

    if (!empty($pending['ticket_id'])) {
        m24_json(['success'=>false,'message'=>'TICKET_ALREADY_CREATED'],409);
    }

    $payload = json_decode((string)$pending['payload_json'], true);

    if (!is_array($payload)) {
        m24_json(['success'=>false,'message'=>'INVALID_PAYLOAD'],500);
    }

    $amount = (float)($payload['request']['cijena'] ?? 0);

    if ($amount <= 0) {
        m24_json(['success'=>false,'message'=>'INVALID_AMOUNT'],400);
    }

    /* ================= CARD TOKEN ================= */

    $stmt = $pdo->prepare("
        SELECT payment_tks_transactionid
        FROM vtiger_payment
        WHERE paymentid=?
        AND payment_tks_customeremail=?
        AND payment_tks_status NOT IN ('FAILED','DEACTIVATED')
        LIMIT 1
    ");

    $stmt->execute([$cardId, $email]);
    $card = $stmt->fetch();

    if (!$card) {
        m24_json(['success'=>false,'message'=>'CARD_NOT_FOUND'],404);
    }

    $referenceUuid = trim((string)($card['payment_tks_transactionid'] ?? ''));

    if ($referenceUuid === '' || str_starts_with($referenceUuid, 'RG-')) {
        m24_json(['success'=>false,'message'=>'CARD_NOT_READY'],400);
    }

    /* ================= BANKART CLIENT ================= */

    $client = new Client(
        $env['BANKART_API_USER'],
        $env['BANKART_API_PASSWORD'],
        $env['BANKART_API_KEY'],
        $env['BANKART_SHARED_SECRET'],
        'EN'
    );

    /* ================= URLS ================= */

    $callbackUrl = "https://majstor24.ba/api/payment/callback_ticket_mobile.php";
    $successUrl  = "https://majstor24.ba/api/payment/mobile_success_ticket.php?trx=".$merchantTrxId;

    /* ================= CREATE DEBIT ================= */

    $debit = new Debit();

    $debit
        ->setTransactionId($merchantTrxId)
        ->setAmount($amount)
        ->setCurrency('BAM')
        ->setDescription('Majstor24 ASSISTANCE MOBILE')
        ->setSuccessUrl($successUrl)
        ->setErrorUrl($successUrl)
        ->setCancelUrl($successUrl)
        ->setCallbackUrl($callbackUrl)
        ->setTransactionIndicator('CARDONFILE')
        ->setReferenceUuid($referenceUuid);

    /* ================= CUSTOMER ================= */

    $customer = (new Customer())
        ->setIdentification((string)$contactId)
        ->setFirstName((string)($user['firstname'] ?? ''))
        ->setLastName((string)($user['lastname'] ?? ''))
        ->setEmail($email)
        ->setIpAddress($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1')
        ->setBillingAddress1((string)($user['mailingstreet'] ?? ''))
        ->setBillingCity((string)($user['mailingcity'] ?? 'Sarajevo'))
        ->setBillingPostcode((string)($user['mailingzip'] ?? '71000'))
        ->setBillingCountry('BA');

    $debit->setCustomer($customer);

    /* ================= EXECUTE ================= */

    $bankartRes = $client->debit($debit);

    if (!$bankartRes->isSuccess()) {

        error_log("BANKART_FAILED: ".json_encode($bankartRes->toArray()));

        m24_json([
            'success'=>false,
            'message'=>'BANKART_FAILED'
        ],502);
    }

    $bankartData = $bankartRes->toArray();

    m24_json([
        'success'=>true,
        'redirectUrl'=>$bankartData['redirectUrl'] ?? '',
        'merchant_trx_id'=>$merchantTrxId
    ]);

} catch (Throwable $e) {

    error_log('START_BANKART_TRANSACTION_ERROR: '.$e->getMessage());

    m24_json([
        'success'=>false,
        'message'=>'SERVER_ERROR',
        'debug'=>$e->getMessage()
    ],500);
}
