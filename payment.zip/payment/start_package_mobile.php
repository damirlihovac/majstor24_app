<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

require_once __DIR__ . '/../../placanje/php_sdk/PHPPaymentGatewayJson3.0.1/autoload.php';

use PaymentGatewayJson\Client\Client;
use PaymentGatewayJson\Client\Transaction\Debit;

function m24_json(array $arr, int $code = 200): void {
    http_response_code($code);
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit;
}

try {

    /* ================= ENV ================= */
    $env = @parse_ini_file('/var/www/majstor24_env/core-api.env') ?: [];
    if (!$env) throw new Exception('ENV_NOT_LOADED');

    /* ================= DB ================= */
    $pdo = new PDO(
        "mysql:host={$env['M24_DB_HOST']};dbname={$env['M24_DB_NAME']};charset=utf8mb4",
        $env['M24_DB_USER'],
        $env['M24_DB_PASS'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    /* ================= AUTH ================= */
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authHeader = $headers['Authorization'] ?? ($headers['authorization'] ?? '');

    if (!preg_match('/Bearer\s+(\S+)/i', $authHeader, $m)) {
        m24_json(['success' => false, 'message' => 'TOKEN_MISSING'], 401);
    }

    $token = trim($m[1]);

    $stmt = $pdo->prepare("
        SELECT contactid,email
        FROM vtiger_contactdetails
        WHERE api_token = ?
        LIMIT 1
    ");
    $stmt->execute([$token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        m24_json(['success' => false, 'message' => 'INVALID_TOKEN'], 401);
    }

    $contactId   = (int)$user['contactid'];
    $email       = (string)$user['email'];
    $contactWsId = '12x' . $contactId;

    /* ================= INPUT ================= */
    $input = json_decode(file_get_contents('php://input'), true) ?: [];

    $paymentId = (int)($input['paymentid'] ?? 0);
    $amount    = (float)($input['amount'] ?? 0);
    $currency  = strtoupper((string)($input['currency'] ?? 'BAM'));
    $packages  = $input['packages'] ?? [];

    if (!$paymentId || $amount <= 0 || empty($packages) || !is_array($packages)) {
        m24_json(['success' => false, 'message' => 'INVALID_INPUT'], 400);
    }

    /* ================= CARD (COF) ================= */
    $stmt = $pdo->prepare("
        SELECT payment_tks_bankardtransaction
        FROM vtiger_payment
        WHERE paymentid = ?
        AND payment_tks_status = 'REGISTERED'
        LIMIT 1
    ");
    $stmt->execute([$paymentId]);
    $card = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$card) {
        m24_json(['success' => false, 'message' => 'CARD_NOT_FOUND'], 404);
    }

    $referenceUuid = (string)$card['payment_tks_bankardtransaction'];

    if (!$referenceUuid) {
        m24_json(['success' => false, 'message' => 'CARD_NOT_READY'], 400);
    }

    /* ================= TRX ================= */
    $merchantTrxId = "PKG-{$contactId}-" . date('YmdHis') . "-" . bin2hex(random_bytes(3));

    /* ================= PENDING ================= */
    $pdo->prepare("
        INSERT INTO m24_pending_package (trx, contact_id, created_at)
        VALUES (?, ?, NOW())
    ")->execute([$merchantTrxId, $contactId]);

    /* ================= BANKART ================= */
    $client = new Client(
        $env['BANKART_API_USER'],
        $env['BANKART_API_PASSWORD'],
        $env['BANKART_API_KEY'],
        $env['BANKART_SHARED_SECRET'],
        'EN'
    );

    $debit = new Debit();

    $debit
        ->setMerchantTransactionId($merchantTrxId) /* ✅ FIX */
        ->setAmount($amount)
        ->setCurrency($currency)
        ->setDescription("Majstor24 PACKAGE MOBILE")
        ->setCallbackUrl("https://majstor24.ba/api/payment/callback_package_mobile.php")
        ->setSuccessUrl("https://majstor24.ba/api/payment/mobile_success_package.php?trx=" . $merchantTrxId)
        ->setErrorUrl("https://majstor24.ba/api/payment/mobile_success_package.php?trx=" . $merchantTrxId)
        ->setCancelUrl("https://majstor24.ba/api/payment/mobile_success_package.php?trx=" . $merchantTrxId)
        ->setTransactionIndicator('CARDONFILE')
        ->setReferenceUuid($referenceUuid);

    error_log("COF PACKAGE REG ID: ".$referenceUuid);

    $bankartRes = $client->debit($debit);

    $bankartData = $bankartRes->toArray();

    error_log("BANKART PACKAGE RESPONSE: ".json_encode($bankartData));

    if (!$bankartRes->isSuccess()) {
        m24_json([
            'success' => false,
            'message' => 'BANKART_FAILED',
            'bankart' => $bankartData
        ], 400);
    }

    /* ================= RESPONSE ================= */
    m24_json([
        'success'        => true,
        'redirectUrl'    => $bankartData['redirectUrl'] ?? '',
        'merchantTrxId'  => $merchantTrxId,
        'merchant_trx_id'=> $merchantTrxId
    ]);

} catch (Throwable $e) {

    m24_json([
        'success' => false,
        'message' => 'SERVER_ERROR',
        'debug'   => $e->getMessage()
    ], 500);

}
