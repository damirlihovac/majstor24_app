<?php
declare(strict_types=1);

ini_set('display_errors','0');
ini_set('log_errors','1');
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../placanje/php_sdk/PHPPaymentGatewayJson3.0.1/autoload.php';

use PaymentGatewayJson\Client\Client;
use PaymentGatewayJson\Client\Data\Customer;
use PaymentGatewayJson\Client\Data\ThreeDSecureData;
use PaymentGatewayJson\Client\Transaction\Register;

$logFile = '/var/log/majstor24/start_register_mobile.log';

/* ================= HELPERS ================= */

function m24_log($m){
    global $logFile;
    file_put_contents($logFile,'['.date('c').'] '.$m.PHP_EOL,FILE_APPEND);
}

function m24_json($arr,$code=200){
    http_response_code($code);
    echo json_encode($arr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* ================= START ================= */

try{

    /* ================= ENV ================= */

    $env = @parse_ini_file('/var/www/majstor24_env/core-api.env') ?: [];
    if(!$env){
        m24_log('ENV_ERROR');
        m24_json(['success'=>false,'message'=>'ENV_ERROR'],500);
    }

    /* ================= DB ================= */

    $pdo = new PDO(
        "mysql:host={$env['M24_DB_HOST']};dbname={$env['M24_DB_NAME']};charset=utf8mb4",
        $env['M24_DB_USER'],
        $env['M24_DB_PASS'],
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]
    );

    /* ================= AUTH (TOKEN) ================= */

    $authHeader =
        $_SERVER['HTTP_AUTHORIZATION']
        ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
        ?? '';

    if(!preg_match('/Bearer\s+(.*)$/i',$authHeader,$m)){
        m24_log('NO_TOKEN');
        m24_json(['success'=>false,'message'=>'NO_TOKEN'],401);
    }

    $token = trim($m[1]);

    m24_log("TOKEN=$token");

    $stmt = $pdo->prepare("
        SELECT contactid
        FROM vtiger_contactdetails
        WHERE api_token = ?
        LIMIT 1
    ");
    $stmt->execute([$token]);

    $contactId = (int)$stmt->fetchColumn();

    if($contactId <= 0){
        m24_log('INVALID_TOKEN');
        m24_json(['success'=>false,'message'=>'INVALID_TOKEN'],401);
    }

    m24_log("CONTACT_ID=$contactId");

    /* ================= USER ================= */

    $stmt = $pdo->prepare("
        SELECT
            c.firstname,
            c.lastname,
            c.email,
            a.mailingstreet,
            a.mailingcity,
            a.mailingzip
        FROM vtiger_contactdetails c
        LEFT JOIN vtiger_contactaddress a
            ON a.contactaddressid = c.contactid
        WHERE c.contactid = ?
        LIMIT 1
    ");
    $stmt->execute([$contactId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if(!$user){
        m24_log('USER_NOT_FOUND');
        m24_json(['success'=>false,'message'=>'USER_NOT_FOUND'],404);
    }

    /* ================= BANKART ================= */

    $client = new Client(
        $env['BANKART_API_USER'],
        $env['BANKART_API_PASSWORD'],
        $env['BANKART_API_KEY'],
        $env['BANKART_SHARED_SECRET'],
        'EN'
    );

    $trx = 'RG-'.$contactId.'-'.date('YmdHis').'-'.bin2hex(random_bytes(3));

    $callbackUrl = "https://majstor24.ba/api/payment/callback_register_mobile.php";

    $successUrl = 'https://majstor24.ba/api/payment/mobile_register_success.php?trx='.$trx;
    $errorUrl   = 'https://majstor24.ba/api/payment/mobile_register_error.php?trx='.$trx;
    $cancelUrl  = 'https://majstor24.ba/api/payment/mobile_register_cancel.php?trx='.$trx;

    m24_log("TRX=$trx");

    /* ================= CUSTOMER ================= */

    $customer = new Customer();
    $customer->setFirstName($user['firstname'] ?: 'N/A')
             ->setLastName($user['lastname'] ?: 'N/A')
             ->setEmail($user['email'] ?: 'test@test.com')
             ->setIpAddress($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1')
             ->setBillingAddress1($user['mailingstreet'] ?: 'Street')
             ->setBillingCity($user['mailingcity'] ?: 'Sarajevo')
             ->setBillingPostcode($user['mailingzip'] ?: '71000')
             ->setBillingCountry('BA')
             ->setIdentification((string)$contactId);


    /* ================= REGISTER ================= */

    $register = new Register();
    $register->setMerchantTransactionId($trx)
             ->setCallbackUrl($callbackUrl)
             ->setSuccessUrl($successUrl)
             ->setErrorUrl($errorUrl)
             ->setCancelUrl($cancelUrl)
             ->setDescription('Majstor24 Card Registration')
             ->setCustomer($customer)
             ->setThreeDSecureData($threeDS);

    /* ✅ KLJUČNO: čuvamo kontakt za callback */
$register->setTransactionIndicator('INITIAL');

    /* 🔥 DEBUG */
    m24_log("REGISTER_REQUEST trx=$trx");

    $result = $client->register($register);

    if (!method_exists($result, 'getRedirectUrl')) {
        m24_log('BANKART_INVALID_RESPONSE');
        m24_json(['success'=>false,'message'=>'BANKART_ERROR'],500);
    }

    $redirectUrl = $result->getRedirectUrl();

    if(!$redirectUrl){
        m24_log('NO_REDIRECT_URL');
        m24_json(['success'=>false,'message'=>'NO_REDIRECT'],500);
    }

    m24_log('REDIRECT='.$redirectUrl);

    /* ================= SAVE PENDING ================= */

    $stmt = $pdo->prepare("
        INSERT INTO m24_pending_register (trx, contact_id, created_at)
        VALUES (?, ?, NOW())
    ");
    $stmt->execute([$trx,$contactId]);

    m24_log("PENDING_SAVED trx=$trx contact=$contactId");

    /* ================= RESPONSE ================= */

    m24_json([
        'success'=>true,
        'redirectUrl'=>$redirectUrl,
        'trx'=>$trx
    ]);

}catch(Throwable $e){

    m24_log('ERROR='.$e->getMessage());

    m24_json([
        'success'=>false,
        'message'=>'SERVER_ERROR'
    ],500);
}
