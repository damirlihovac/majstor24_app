<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

// TAČNA PUTANJA (bez duplog majstor24)
require __DIR__ . '/../../placanje/start_transaction_saved_ticket.php';
