<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

ini_set('display_errors','0');
ini_set('log_errors','1');
ini_set('error_log', __DIR__.'/start_ticket_mobile_error.log');
error_reporting(E_ALL);

require_once __DIR__.'/../../placanje/php_sdk/PHPPaymentGatewayJson3.0.1/autoload.php';

use PaymentGatewayJson\Client\Client;
use PaymentGatewayJson\Client\Transaction\Debit;

function m24_json(array $arr,int $code=200){
    http_response_code($code);
    echo json_encode($arr,JSON_UNESCAPED_UNICODE);
    exit;
}

try{

/* ================= ENV ================= */

$env = parse_ini_file('/var/www/majstor24_env/core-api.env');

$pdo = new PDO(
    "mysql:host={$env['M24_DB_HOST']};dbname={$env['M24_DB_NAME']};charset=utf8mb4",
    $env['M24_DB_USER'],
    $env['M24_DB_PASS'],
    [
        PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC
    ]
);

/* ================= AUTH ================= */

$headers = function_exists('getallheaders') ? getallheaders() : [];
$authHeader = $headers['Authorization'] ?? '';

preg_match('/Bearer\s+(\S+)/',$authHeader,$m);
$token = $m[1] ?? '';

$stmt = $pdo->prepare("
SELECT contactid,email
FROM vtiger_contactdetails
WHERE api_token = ?
LIMIT 1
");
$stmt->execute([$token]);
$user = $stmt->fetch();

if(!$user){
    m24_json(["success"=>false,"message"=>"INVALID_TOKEN"],401);
}

$contactId   = (int)$user["contactid"];
$email       = $user["email"];
$contactWsId = "12x".$contactId;

/* ================= INPUT ================= */

$input = json_decode(file_get_contents("php://input"),true) ?: [];

$merchantTrxId = $input["merchant_trx_id"] ?? "";
$cardId        = (int)($input["card_id"] ?? 0);

if(!$merchantTrxId || !$cardId){
    m24_json(["success"=>false,"message"=>"INVALID_INPUT"],400);
}

/* ================= LOAD PENDING ================= */

$stmt = $pdo->prepare("
SELECT payload_json
FROM m24_pending_ticket
WHERE merchant_trx_id = ?
LIMIT 1
");

$stmt->execute([$merchantTrxId]);
$row = $stmt->fetch();

if(!$row){
    m24_json(["success"=>false,"message"=>"PENDING_NOT_FOUND"],404);
}

$payload = json_decode($row["payload_json"], true);

/* ================= AMOUNT ================= */

$amount = (float)($payload["request"]["cijena"] ?? 0);

if($amount <= 0){
    m24_json(["success"=>false,"message"=>"INVALID_AMOUNT"],400);
}

/* ================= CARD (COF TOKEN) ================= */

$stmt = $pdo->prepare("
SELECT payment_tks_bankardtransaction
FROM vtiger_payment
WHERE paymentid = :id
AND payment_tks_status = 'REGISTERED'
LIMIT 1
");

$stmt->execute([
    ':id' => $cardId
]);

$card = $stmt->fetch();

$referenceUuid = $card["payment_tks_bankardtransaction"] ?? "";

if(!$referenceUuid){
    m24_json(["success"=>false,"message"=>"CARD_NOT_READY"],400);
}

/* ================= BANKART ================= */

$client = new Client(
    $env["BANKART_API_USER"],
    $env["BANKART_API_PASSWORD"],
    $env["BANKART_API_KEY"],
    $env["BANKART_SHARED_SECRET"],
    "EN"
);

$debit = new Debit();

$debit
->setMerchantTransactionId($merchantTrxId) /* ✅ FIX */
->setAmount($amount)
->setCurrency("BAM")
->setDescription("Majstor24 ASSISTANCE MOBILE")
->setSuccessUrl("https://majstor24.ba/api/payment/mobile_success_ticket.php?trx=".$merchantTrxId)
->setErrorUrl("https://majstor24.ba/api/payment/mobile_success_ticket.php?trx=".$merchantTrxId)
->setCancelUrl("https://majstor24.ba/api/payment/mobile_success_ticket.php?trx=".$merchantTrxId)
->setCallbackUrl("https://majstor24.ba/api/payment/callback_ticket_mobile.php")
->setTransactionIndicator("CARDONFILE")
->setReferenceUuid($referenceUuid);

/* DEBUG */
error_log("COF REGISTRATION ID: ".$referenceUuid);

$response = $client->debit($debit);

$responseArray = $response->toArray();

/* LOG FULL RESPONSE */
error_log("BANKART RESPONSE: ".json_encode($responseArray));

if(!$response->isSuccess()){

    m24_json([
        "success"=>false,
        "message"=>"BANKART_FAILED",
        "bankart"=>$responseArray
    ],400);
}

/* ================= RESPONSE ================= */

m24_json([
    "success"=>true,
    "redirectUrl"=>$responseArray["redirectUrl"] ?? "",
    "merchant_trx_id"=>$merchantTrxId
]);

}catch(Throwable $e){

error_log("FATAL ERROR: ".$e->getMessage());

m24_json([
    "success"=>false,
    "message"=>"SERVER_ERROR",
    "debug"=>$e->getMessage()
],500);

}
