<?php
require_once 'db.php';

$trx = $_GET['merchant_trx_id'] ?? '';

$stmt = $pdo->prepare("
    SELECT status, ticket_id
    FROM m24_pending_ticket
    WHERE merchant_trx_id = :trx
    LIMIT 1
");
$stmt->execute(['trx' => $trx]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    echo json_encode(['success' => false]);
    exit;
}

echo json_encode([
    'success' => true,
    'status'  => $row['status'],
    'ticket_id' => $row['ticket_id']
]);
