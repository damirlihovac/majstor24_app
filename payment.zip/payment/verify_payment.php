<?php
declare(strict_types=1);

ob_start();
ini_set('display_errors', '0');
error_reporting(0);

header("Content-Type: application/json; charset=utf-8");

function m24_json(array $arr, int $code = 200): void {
    http_response_code($code);
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit;
}

/* ================================
 * INPUT
 * ================================ */
$raw = file_get_contents('php://input') ?: '';
$json = json_decode($raw, true);
if (!is_array($json)) $json = [];

$tx = $json['tx']
    ?? ($_POST['tx']
    ?? ($_GET['tx']
    ?? null));

if (!$tx) {
    m24_json(['success' => false, 'status' => 'MISSING_TX'], 400);
}

/* ================================
 * DB CONNECT
 * ================================ */
$env = @parse_ini_file('/var/www/majstor24_env/core-api.env') ?: [];
if (!$env) {
    m24_json(['success' => false, 'status' => 'ENV_NOT_LOADED'], 500);
}

try {
    $pdo = new PDO(
        "mysql:host={$env['M24_DB_HOST']};dbname={$env['M24_DB_NAME']};charset=utf8mb4",
        $env['M24_DB_USER'],
        $env['M24_DB_PASS'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (Throwable $e) {
    m24_json(['success' => false, 'status' => 'SERVER_ERROR'], 500);
}

/* ================================
 * FIND PAYMENT BY merchantTrxId
 * - merchantTrxId je payment_tks_paymentno
 * ================================ */
$stmt = $pdo->prepare("
    SELECT
        paymentid,
        payment_tks_status,
        payment_tks_replatedto,
        payment_tks_relatiranonaosnovu
    FROM vtiger_payment
    WHERE payment_tks_paymentno = :mtx
    ORDER BY paymentid DESC
    LIMIT 1
");
$stmt->execute(['mtx' => $tx]);
$payment = $stmt->fetch();

if (!$payment) {
    m24_json(['success' => false, 'status' => 'NOT_FOUND'], 404);
}

if (($payment['payment_tks_status'] ?? '') !== 'SUCCESS') {
    m24_json(['success' => false, 'status' => 'NOT_PAID'], 409);
}

/* ================================
 * Extract contactId
 * ================================ */
$wsId = (string)($payment['payment_tks_replatedto'] ?? '');
$contactId = (int)str_replace('12x', '', $wsId);
if ($contactId <= 0) {
    m24_json(['success' => false, 'status' => 'CONTACT_MISSING'], 500);
}

/* ================================
 * Korpa from Payment
 * ================================ */
$korpaJson = (string)($payment['payment_tks_relatiranonaosnovu'] ?? '');
$korpa = json_decode($korpaJson, true);

/* fallback: ako iz nekog razloga nije upisana u Payment, čitaj iz pending */
if (!is_array($korpa) || count($korpa) === 0) {
    $stmt = $pdo->prepare("SELECT payload_json FROM m24_pending_package WHERE merchant_trx_id = :mtx LIMIT 1");
    $stmt->execute(['mtx' => $tx]);
    $row = $stmt->fetch();
    if ($row && !empty($row['payload_json'])) {
        $korpa = json_decode((string)$row['payload_json'], true);
    }
}

if (!is_array($korpa) || count($korpa) === 0) {
    m24_json(['success' => false, 'status' => 'KORPA_MISSING'], 500);
}

/* ================================
 * Dedupe (idempotent)
 * - spriječi duplo kreiranje za isti tx
 * - ovdje koristiš jednostavan marker u potential description
 *   (ako imaš bolje polje, prebaci)
 * ================================ */
$check = $pdo->prepare("
    SELECT 1
    FROM vtiger_potential p
    INNER JOIN vtiger_crmentity e ON e.crmid = p.potentialid
    WHERE e.deleted = 0
      AND p.description LIKE :needle
    LIMIT 1
");
$check->execute(['needle' => "%$tx%"]);
if ($check->fetch()) {
    m24_json(['success' => true, 'status' => 'OPPORTUNITY_CREATED']);
}

/* ================================
 * CALL create_opportunity.php (sad sa korpom)
 * ================================ */
$ch = curl_init("https://majstor24.ba/api/create_opportunity.php");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => http_build_query([
        'contact_id' => $contactId,
        'korpa'      => json_encode($korpa, JSON_UNESCAPED_UNICODE),
        'tx'         => $tx
    ]),
    CURLOPT_TIMEOUT        => 25
]);

$response = curl_exec($ch);
curl_close($ch);

$decoded = json_decode((string)$response, true);

if (empty($decoded['success'])) {
    m24_json([
        'success' => false,
        'status'  => 'OPPORTUNITY_FAILED',
        'debug'   => $decoded
    ], 500);
}

m24_json([
    'success' => true,
    'status'  => 'OPPORTUNITY_CREATED'
]);
