<?php
declare(strict_types=1);

header("Content-Type: application/json");

$env = parse_ini_file('/var/www/majstor24_env/core-api.env');

$pdo = new PDO(
    "mysql:host={$env['M24_DB_HOST']};dbname={$env['M24_DB_NAME']};charset=utf8mb4",
    $env['M24_DB_USER'],
    $env['M24_DB_PASS'],
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);

/* ================= INPUT ================= */

$trx = $_GET['trx'] ?? '';

if (!$trx) {
    echo json_encode(['success'=>false,'status'=>'NO_TRX']);
    exit;
}

/* ================= CHECK PAYMENT ================= */

$stmt = $pdo->prepare("
    SELECT paymentid
    FROM vtiger_payment
    WHERE payment_tks_paymentno = ?
    AND payment_tks_status = 'REGISTERED'
    LIMIT 1
");
$stmt->execute([$trx]);

$payment = $stmt->fetch();

if ($payment) {
    echo json_encode([
        'success'=>true,
        'status'=>'REGISTERED'
    ]);
    exit;
}

/* ================= CHECK TIMEOUT ================= */

$stmt = $pdo->prepare("
    SELECT created_at
    FROM m24_pending_register
    WHERE trx = ?
    LIMIT 1
");
$stmt->execute([$trx]);

$pending = $stmt->fetch();

if (!$pending) {
    echo json_encode(['success'=>false,'status'=>'NOT_FOUND']);
    exit;
}

$created = strtotime($pending['created_at']);
$now = time();

if ($now - $created > 120) {
    echo json_encode(['success'=>false,'status'=>'TIMEOUT']);
    exit;
}

/* ================= STILL PROCESSING ================= */

echo json_encode([
    'success'=>true,
    'status'=>'PENDING'
]);
