<?php
declare(strict_types=1);

header("Content-Type: application/json; charset=utf-8");

ini_set('display_errors','0');
ini_set('log_errors','1');
ini_set('error_log', __DIR__ . '/verify_ticket_payment_error.log');
error_reporting(E_ALL);

function respond(int $code,array $data){
    http_response_code($code);
    echo json_encode($data,JSON_UNESCAPED_UNICODE);
    exit;
}

/* =========================================================
   ENV
========================================================= */

$env=parse_ini_file('/var/www/majstor24_env/core-api.env');

if(!$env){
    respond(500,[
        "success"=>false,
        "status"=>"ENV_ERROR"
    ]);
}

/* =========================================================
   DB
========================================================= */

$pdo=new PDO(
"mysql:host={$env['M24_DB_HOST']};dbname={$env['M24_DB_NAME']};charset=utf8mb4",
$env['M24_DB_USER'],
$env['M24_DB_PASS'],
[
PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC
]
);

/* =========================================================
   INPUT
========================================================= */

$trx=trim($_GET['trx'] ?? '');

if(!$trx){
    respond(400,[
        "success"=>false,
        "status"=>"MISSING_TRX"
    ]);
}

/* =========================================================
   LOAD PENDING
========================================================= */

$stmt=$pdo->prepare("
SELECT status,ticket_id
FROM m24_pending_ticket
WHERE merchant_trx_id=?
ORDER BY id DESC
LIMIT 1
");

$stmt->execute([$trx]);

$row=$stmt->fetch();

if(!$row){
    respond(404,[
        "success"=>false,
        "status"=>"PENDING_NOT_FOUND"
    ]);
}

/* =========================================================
   STATUS MAP
========================================================= */

$status=$row['status'];
$ticketId=$row['ticket_id'] ?? null;

/*
POSSIBLE STATES

PENDING
PAID
CREATED
SUCCESS
FAILED
PAYMENT_FAILED
*/

if($status==="SUCCESS" && $ticketId){

    respond(200,[
        "success"=>true,
        "status"=>"TICKET_CREATED",
        "ticket_id"=>$ticketId
    ]);

}

if($status==="CREATED" && $ticketId){

    respond(200,[
        "success"=>true,
        "status"=>"TICKET_CREATED",
        "ticket_id"=>$ticketId
    ]);

}

if($status==="PAID"){

    respond(200,[
        "success"=>true,
        "status"=>"PAYMENT_SUCCESS_WAITING_TICKET"
    ]);

}

if(str_starts_with($status,"PAYMENT_")){

    respond(200,[
        "success"=>false,
        "status"=>"PAYMENT_FAILED"
    ]);

}

respond(200,[
    "success"=>true,
    "status"=>"PAYMENT_PENDING"
]);
