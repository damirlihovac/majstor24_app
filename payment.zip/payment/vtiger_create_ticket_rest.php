<?php
declare(strict_types=1);

ini_set('display_errors','0');
ini_set('log_errors','1');
ini_set('error_log', __DIR__ . '/vtiger_create_ticket_rest_error.log');
error_reporting(E_ALL);

header("Content-Type: application/json; charset=utf-8");

function respond(int $code, array $data){
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

$vtigerConfig = '/var/www/html/crmmajstor24/config.inc.php';

if(!file_exists($vtigerConfig)){
    respond(500,["success"=>false,"message"=>"CRM_CONFIG_NOT_FOUND"]);
}

require_once $vtigerConfig;

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try{

$db = new mysqli(
    $dbconfig['db_server'],
    $dbconfig['db_username'],
    $dbconfig['db_password'],
    $dbconfig['db_name']
);

$db->set_charset("utf8mb4");

}catch(Throwable $e){

respond(500,["success"=>false,"message"=>"DB_CONNECT_ERROR"]);

}

$raw = file_get_contents("php://input");
$data = json_decode($raw,true);

if(!is_array($data)){
    respond(400,["success"=>false,"message"=>"INVALID_JSON"]);
}

$contactId = $data['contact_id'] ?? null;
$title     = $data['title'] ?? null;
$desc      = $data['description'] ?? null;

if(!$contactId || !$title){
    respond(400,["success"=>false,"message"=>"MISSING_FIELDS"]);
}

/* =========================
   VTIGER WS LOGIN
========================= */

$endpoint = "https://pgmcrm.pgm.ba/webservice.php";

$ch = curl_init($endpoint."?operation=getchallenge&username=apiuser");
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
$res = curl_exec($ch);
curl_close($ch);

$data = json_decode($res,true);

if(!$data['success']){
    respond(500,["success"=>false,"message"=>"CHALLENGE_FAILED"]);
}

$challenge = $data['result']['token'];

$accessKey = md5($challenge . "API_ACCESS_KEY");

$post = [
    "operation"=>"login",
    "username"=>"apiuser",
    "accessKey"=>$accessKey
];

$ch = curl_init($endpoint);
curl_setopt($ch,CURLOPT_POST,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$post);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);

$res = curl_exec($ch);
curl_close($ch);

$data = json_decode($res,true);

if(!$data['success']){
    respond(500,["success"=>false,"message"=>"LOGIN_FAILED"]);
}

$session = $data['result']['sessionName'];

/* =========================
   CREATE TICKET
========================= */

$element = [
    "ticket_title"=>$title,
    "description"=>$desc,
    "contact_id"=>"12x".$contactId
];

$post = [
    "operation"=>"create",
    "sessionName"=>$session,
    "elementType"=>"HelpDesk",
    "element"=>json_encode($element)
];

$ch = curl_init($endpoint);
curl_setopt($ch,CURLOPT_POST,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$post);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);

$res = curl_exec($ch);
curl_close($ch);

$data = json_decode($res,true);

if(!$data['success']){
    respond(500,["success"=>false,"message"=>"TICKET_CREATE_FAILED"]);
}

$wsid = $data['result']['id'];

$parts = explode("x",$wsid);

respond(200,[
    "success"=>true,
    "ticket_id"=>$parts[1]
]);
